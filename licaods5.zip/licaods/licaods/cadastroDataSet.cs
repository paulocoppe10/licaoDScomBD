﻿namespace licaods
{


    partial class cadastroDataSet
    {
    }
}

namespace licaods.cadastroDataSetTableAdapters {
    
    
    public partial class tbusuarioTableAdapter {
    }
}
