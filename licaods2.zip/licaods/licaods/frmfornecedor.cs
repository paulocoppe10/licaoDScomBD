﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace licaods
{
    public partial class frmfornecedor : Form
    {
        public frmfornecedor()
        {
            InitializeComponent();
        }

        private void frmfornecedor_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cadastroDataSet.tbfornecedor' table. You can move, or remove it, as needed.
            this.tbfornecedorTableAdapter.Fill(this.cadastroDataSet.tbfornecedor);

        }
    }
}
